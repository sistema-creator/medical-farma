'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { LogIn, Mail, Lock, AlertCircle } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useAuthStore } from '@/store/authStore'
import Header from '@/components/Header'
import Footer from '@/components/Footer'

export default function LoginPage() {
    const router = useRouter()
    const { login } = useAuthStore()
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault()
        setError('')

        // Demo login - En producción esto sería una llamada a API
        if (email && password) {
            // Simular diferentes roles para demostración
            let role: 'hospital' | 'farmacia' = 'hospital'
            if (email.includes('farmacia')) {
                role = 'farmacia'
            }

            login({
                id: '1',
                name: 'Usuario Demo',
                email,
                role,
                approved: true,
            })

            router.push('/catalogo')
        } else {
            setError('Por favor complete todos los campos')
        }
    }

    return (
        <>
            <Header />
            <main className="min-h-screen pt-20 gradient-bg flex items-center justify-center py-12">
                <div className="container mx-auto px-4">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="max-w-md mx-auto"
                    >
                        <div className="card">
                            <div className="text-center mb-8">
                                <div className="w-16 h-16 medical-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                                    <LogIn className="text-white" size={32} />
                                </div>
                                <h1 className="text-3xl font-bold text-medical-gray-900 mb-2">
                                    Iniciar Sesión
                                </h1>
                                <p className="text-medical-gray-600">
                                    Portal exclusivo para instituciones de salud
                                </p>
                            </div>

                            {error && (
                                <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-start space-x-3">
                                    <AlertCircle className="text-red-600 flex-shrink-0 mt-0.5" size={20} />
                                    <p className="text-red-700">{error}</p>
                                </div>
                            )}

                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div>
                                    <label className="block text-sm font-semibold text-medical-gray-700 mb-2">
                                        Correo Electrónico
                                    </label>
                                    <div className="relative">
                                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-medical-gray-400" size={20} />
                                        <input
                                            type="email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            className="w-full pl-11 pr-4 py-3 border border-medical-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue-500 focus:border-transparent transition-all"
                                            placeholder="su@email.com"
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-sm font-semibold text-medical-gray-700 mb-2">
                                        Contraseña
                                    </label>
                                    <div className="relative">
                                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-medical-gray-400" size={20} />
                                        <input
                                            type="password"
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                            className="w-full pl-11 pr-4 py-3 border border-medical-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue-500 focus:border-transparent transition-all"
                                            placeholder="••••••••"
                                        />
                                    </div>
                                </div>

                                <div className="flex items-center justify-between">
                                    <label className="flex items-center space-x-2">
                                        <input type="checkbox" className="w-4 h-4 text-medical-blue-600 rounded" />
                                        <span className="text-sm text-medical-gray-600">Recordarme</span>
                                    </label>
                                    <Link href="/recuperar" className="text-sm text-medical-blue-600 hover:text-medical-blue-700 font-medium">
                                        ¿Olvidó su contraseña?
                                    </Link>
                                </div>

                                <button type="submit" className="btn-primary w-full">
                                    Ingresar
                                </button>
                            </form>

                            <div className="mt-8 pt-6 border-t border-medical-gray-200 text-center">
                                <p className="text-medical-gray-600 mb-4">
                                    ¿No tiene una cuenta?
                                </p>
                                <Link href="/registro" className="btn-secondary w-full block text-center">
                                    Solicitar Apertura de Cuenta
                                </Link>
                            </div>

                            <div className="mt-6 p-4 bg-medical-blue-50 rounded-lg">
                                <p className="text-sm text-medical-gray-700 text-center">
                                    <strong>Demo:</strong> Use cualquier email (ej: hospital@test.com o farmacia@test.com)
                                    con cualquier contraseña para probar el sistema.
                                </p>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </main>
            <Footer />
        </>
    )
}
