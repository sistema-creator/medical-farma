'use client'

import { motion } from 'framer-motion'
import { Calendar, Users, TrendingUp } from 'lucide-react'

export default function History() {
    return (
        <section className="py-20 bg-white">
            <div className="container mx-auto px-4">
                <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-center mb-16"
                >
                    <h2 className="section-title">Nuestra Historia</h2>
                    <p className="section-subtitle">
                        Más de cuatro décadas de compromiso con la salud argentina
                    </p>
                </motion.div>

                <div className="grid lg:grid-cols-2 gap-12 items-center">
                    {/* Timeline */}
                    <motion.div
                        initial={{ opacity: 0, x: -50 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        className="space-y-8"
                    >
                        <div className="flex items-start space-x-4">
                            <div className="flex-shrink-0 w-16 h-16 medical-gradient rounded-full flex items-center justify-center text-white font-bold text-xl">
                                1978
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold text-medical-gray-900 mb-2">Los Inicios</h3>
                                <p className="text-medical-gray-600 leading-relaxed">
                                    David Alberto Vallaro funda Medical Farma con la visión de proveer insumos médicos
                                    de calidad a las instituciones de salud de Entre Ríos.
                                </p>
                            </div>
                        </div>

                        <div className="flex items-start space-x-4">
                            <div className="flex-shrink-0 w-16 h-16 medical-gradient rounded-full flex items-center justify-center text-white font-bold text-xl">
                                1990
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold text-medical-gray-900 mb-2">Expansión Nacional</h3>
                                <p className="text-medical-gray-600 leading-relaxed">
                                    Consolidamos nuestra presencia en todo el país, estableciendo alianzas estratégicas
                                    con las principales marcas internacionales de insumos médicos.
                                </p>
                            </div>
                        </div>

                        <div className="flex items-start space-x-4">
                            <div className="flex-shrink-0 w-16 h-16 medical-gradient rounded-full flex items-center justify-center text-white font-bold text-xl">
                                2010
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold text-medical-gray-900 mb-2">Nueva Generación</h3>
                                <p className="text-medical-gray-600 leading-relaxed">
                                    Germán Vallaro asume la presidencia, modernizando la empresa mientras mantiene
                                    los valores familiares que nos caracterizan.
                                </p>
                            </div>
                        </div>

                        <div className="flex items-start space-x-4">
                            <div className="flex-shrink-0 w-16 h-16 medical-gradient rounded-full flex items-center justify-center text-white font-bold text-xl">
                                2024
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold text-medical-gray-900 mb-2">Transformación Digital</h3>
                                <p className="text-medical-gray-600 leading-relaxed">
                                    Lanzamos nuestra plataforma B2B, facilitando el acceso a nuestro catálogo completo
                                    y optimizando la experiencia de compra para nuestros clientes institucionales.
                                </p>
                            </div>
                        </div>
                    </motion.div>

                    {/* Stats & Values */}
                    <motion.div
                        initial={{ opacity: 0, x: 50 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        className="space-y-6"
                    >
                        <div className="card bg-gradient-to-br from-medical-blue-50 to-white">
                            <div className="flex items-start space-x-4">
                                <Calendar className="text-medical-blue-600 flex-shrink-0" size={40} />
                                <div>
                                    <h3 className="text-3xl font-bold text-medical-blue-600 mb-2">45+ Años</h3>
                                    <p className="text-medical-gray-700 text-lg">
                                        De experiencia ininterrumpida en el sector de la salud, construyendo relaciones
                                        de confianza con instituciones de todo el país.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="card bg-gradient-to-br from-medical-blue-50 to-white">
                            <div className="flex items-start space-x-4">
                                <Users className="text-medical-blue-600 flex-shrink-0" size={40} />
                                <div>
                                    <h3 className="text-3xl font-bold text-medical-blue-600 mb-2">Equipo Dedicado</h3>
                                    <p className="text-medical-gray-700 text-lg">
                                        Contamos con un equipo de profesionales altamente capacitados, comprometidos
                                        con brindar el mejor servicio y asesoramiento técnico.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="card bg-gradient-to-br from-medical-blue-50 to-white">
                            <div className="flex items-start space-x-4">
                                <TrendingUp className="text-medical-blue-600 flex-shrink-0" size={40} />
                                <div>
                                    <h3 className="text-3xl font-bold text-medical-blue-600 mb-2">Crecimiento Continuo</h3>
                                    <p className="text-medical-gray-700 text-lg">
                                        Innovamos constantemente para ofrecer las mejores soluciones en insumos médicos,
                                        adaptándonos a las necesidades cambiantes del sector salud.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>
        </section>
    )
}
